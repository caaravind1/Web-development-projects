<?php
session_start();

// Check if the user is logged in and is an admin
if (!isset($_SESSION['user_id']) || $_SESSION['role_id'] != 2) { // Assuming '2' is the role_id for Admin
    header("Location: login.php"); // Redirect to login if not logged in or not an admin
    exit();
}


?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Home</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <style>
        body {
            background-color: #f8f9fa;
            font-family: Arial, sans-serif;
        }
        .container {
            margin-top: 50px;
        }
        .card {
            margin-bottom: 20px;
        }
        .card-header {
            font-weight: bold;
            background-color: #007bff;
            color: #ffffff;
        }
        .card-body {
            padding: 20px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1 class="text-center">Admin Dashboard</h1>
        <div class="row">
            <div class="col-md-4">
                <div class="card">
                    <div class="card-header">Manage Users</div>
                    <div class="card-body">
                        <p>Add, edit, or remove users.</p>
                        <a href="manage_users.php" class="btn btn-primary">Manage Users</a>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card">
                    <div class="card-header">View Orders</div>
                    <div class="card-body">
                        <p>Check the status of orders.</p>
                        <a href="view_orders.php" class="btn btn-primary">View Orders</a>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card">
                    <div class="card-header">Inventory</div>
                    <div class="card-body">
                        <p>Manage the inventory of products.</p>
                        <a href="inventory.php" class="btn btn-primary">Manage Inventory</a>
                    </div>
                </div>
            </div>
        </div>
        <div class="text-center mt-4">
            <a href="admin_logout.php" class="btn btn-danger">Logout</a>
        </div>
    </div>
</body>
</html>
