<?php
include('db_connection.php');

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['email'];
    $password = $_POST['password'];

    // Check if the email exists in the database and is a staff member
    $sql = "SELECT id, password FROM users WHERE email = ? AND role = 'staff'";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $user = $result->fetch_assoc();
        
        // Verify password
        if (password_verify($password, $user['password'])) {
            session_start();
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['role'] = 'staff';
            header("Location: staff_dashboard.php"); // Redirect to staff dashboard
        } else {
            echo "Invalid password.";
        }
    } else {
        echo "No account found with that email address.";
    }
}
?>

<!-- HTML Form -->
<form method="POST">
    <label for="email">Email:</label>
    <input type="email" name="email" required>
    <label for="password">Password:</label>
    <input type="password" name="password" required>
    <button type="submit">Login</button>
</form>
